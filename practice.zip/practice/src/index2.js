import React from 'react';
import ReactDOM from 'react-dom';

import Demo2 from './demo2';

ReactDOM.render(<Demo2/>, 

);
    